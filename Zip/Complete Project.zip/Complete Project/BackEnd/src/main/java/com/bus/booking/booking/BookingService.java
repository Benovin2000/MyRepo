package com.bus.booking.booking;

import java.util.List;

public interface BookingService {

  
    int register(Booking booking);

    boolean update(Booking booking);

    Booking getBooking(int bookingID);

    List<Booking> getAllBookings();

    boolean delete(int bookingID);

    Booking findByName(String name);

}
