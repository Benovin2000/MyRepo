package com.bus.booking.bus;


import java.util.List;


/**
 * Interface for Bus Service
 */
public interface BusService {

    /**
     * Method to register a bus
     * @param bus
     */
    int register(Bus bus);


    /**
     * Method to update a bus
     * @param bus
     * @return 
     */
    boolean update(Bus bus);

    /**
     * Method to get a bus by ID
     * @param busID
     * @return Bus
     */
    Bus getBus(int busID);

    /**
     * Method to get all buss
     * @return List<Bus>
     */
    List<Bus> getAllBuses();

    /**
     * Method to delete a bus
     * @param busID
     * @return
     */
    boolean delete(int busID);
    
    /**
     * Method to get a bus by Number
     * @param Number
     * @return Bus
     */
    Bus findByNumber(String number);
    
    /**
     * Method to get a bus by Name
     * @param Name
     * @return Bus
     */
    Bus findByName(String name);

}
