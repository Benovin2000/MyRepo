package com.bus.booking.schedule;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ScheduleController {
    
    @Autowired
    private ScheduleService schService;

    
    @PostMapping(value="/schedule/registration", consumes="application/json")
    public int registerSchedule(@RequestBody Schedule sch){
        return schService.register(sch);
    }

    
    @GetMapping(value="/schedule/get/{schID}", produces="application/json")
    public Schedule getScheduleByID(@PathVariable int schID) {
        return schService.getSchedule(schID);
    }

    
    @GetMapping(value="/schedule/listAll", produces="application/json")
    public List<Schedule> getAllSchedules() {
        return schService.getAllSchedules();
    }

    @PutMapping(value="/schedule/update", consumes="application/json")
    public boolean updateSchedule(@RequestBody Schedule sch) {
        return schService.update(sch);
    }

    @DeleteMapping(value="/schedule/delete/{schID}")
    public boolean deleteSchedule(@PathVariable int schID) {
        return schService.delete(schID);
    }    
    
    @GetMapping(value="/schedule/get/{startingpoint}/{destination}/{date}", produces="application/json")
    public Schedule getScheduleByStartingpointAndDestinationAndDate(@PathVariable String startingpoint, @PathVariable String destination, @PathVariable String date) {
        return schService.findByStartingpointAndDestinationAndDate(startingpoint, destination, date);
    }
}
