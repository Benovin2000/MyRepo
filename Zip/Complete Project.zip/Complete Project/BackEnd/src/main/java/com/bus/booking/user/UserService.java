package com.bus.booking.user;

import java.util.List;


/**
 * Interface for User Service
 */
public interface UserService {

    /**
     * Method to register a user
     * @param user
     */
    int register(User user);

    /**
     * Method to login a user
     * @param email
     * @param password
     * @return userID
     */
    User login(String email, String password);

    /**
     * Method to update a user
     * @param user
     * @return 
     */
    boolean update(User user);

    /**
     * Method to get a user by ID
     * @param userID
     * @return User
     */
    User getUser(int userID);

    /**
     * Method to get all users
     * @return List<User>
     */
    List<User> getAllUsers();

    /**
     * Method to delete a user
     * @param userID
     * @return
     */
    boolean delete(int userID);

}
