package com.bus.booking.booking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import java.util.List;


/**
 * Implementation for Booking Service
 */
@Repository
public class BookingServiceImpl implements BookingService {   

    /**
     * Autowired BookingRepository
     */
    @Autowired
    private BookingRepository bookingRepository;

	@Override
	public int register(Booking booking) {
		bookingRepository.save(booking);
        return booking.getId();
	}

	@Override
	public boolean update(Booking bookingNew) {
		 Booking bookingOld = bookingRepository.findById(bookingNew.getId()).orElse(null);
	        if (bookingOld != null) {
	            bookingOld.setName(bookingNew.getName());
	            bookingOld.setRefnumber(bookingNew.getRefnumber());
	            bookingOld.setQuantity(bookingNew.getQuantity());
	            bookingOld.setStatus(bookingNew.getStatus());
	            bookingOld.setAmount(bookingNew.getAmount());
	            bookingRepository.save(bookingOld);
	            return true;
	        }
	        return false;
	}

	@Override
	public Booking getBooking(int bookingID) {
		return bookingRepository.findById(bookingID).orElse(null);
	}

	@Override
	public List<Booking> getAllBookings() {
		return bookingRepository.findAll();
	}
	
	@Override
    public boolean delete(int bookingID) {
        Booking booking = bookingRepository.findById(bookingID).orElse(null);
        if (booking != null) {
            bookingRepository.delete(booking);
            return true;
        }
        return false;
    }
	
	@Override
	public Booking findByName(String name) {
		if (bookingRepository.findByName(name) != null) {
            return bookingRepository.findByName(name);
        }
        return new Booking();
	}
}
