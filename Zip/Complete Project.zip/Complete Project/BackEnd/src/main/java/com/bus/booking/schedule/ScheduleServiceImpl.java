package com.bus.booking.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ScheduleServiceImpl implements ScheduleService {   

    /**
     * Autowired ScheduleRepository
     */
    @Autowired
    private ScheduleRepository schRepository;

	@Override
	public int register(Schedule sch) {
		schRepository.save(sch);
        return sch.getId();
	}

	@Override
	public boolean update(Schedule schNew) {
		Schedule schOld = schRepository.findById(schNew.getId()).orElse(null);
        if (schOld != null) {
            schOld.setDate(schNew.getDate());
            schOld.setBus(schNew.getBus());
            schOld.setStartingpoint(schNew.getStartingpoint());
            schOld.setDestination(schNew.getDestination());
            schOld.setTime(schNew.getTime());
            schOld.setEtadate(schNew.getEtadate());
            schOld.setEtatime(schNew.getEtatime());
            schOld.setAvailability(schNew.getAvailability());
            schOld.setPrice(schNew.getPrice());
            schRepository.save(schOld);
            return true;
        }
        return false;
	}

	@Override
	public Schedule getSchedule(int schID) {
		return schRepository.findById(schID).orElse(null);
	}

	@Override
	public List<Schedule> getAllSchedules() {
		return schRepository.findAll();
	}
	
	@Override
    public boolean delete(int schID) {
        Schedule sch = schRepository.findById(schID).orElse(null);
        if (sch != null) {
            schRepository.delete(sch);
            return true;
        }
        return false;
    }

	@Override
	public Schedule findByStartingpointAndDestinationAndDate(String startingpoint, String destination, String date) {
			if (schRepository.findByStartingpointAndDestinationAndDate(startingpoint, destination, date) != null) {
	            return schRepository.findByDestination(destination);
	        }
	        return new Schedule();
		}	
}
